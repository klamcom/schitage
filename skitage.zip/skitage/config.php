<?php 
    $host = "localhost";

    $dbname = "skitagedb";

    $user = "root";

    $pass = "";

    $conn = new PDO("mysql:host=$host;dbname=$dbname;", $user, $pass);
?>